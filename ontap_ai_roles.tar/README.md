# ontap_ai_ansible
Ansible roles for ONTAP AI 


This is a set of Ansible roles for NetApp A800, Cisco Nexus 3232C and NVIDIA DGX-1 GPU server to deploy the ONTAP AI reference architecture. 
